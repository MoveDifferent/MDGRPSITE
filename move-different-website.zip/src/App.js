import MoveDifferentHomepage from './components/MoveDifferentHomepage';
import './App.css';

function App() {
  return <MoveDifferentHomepage />;
}

export default App;