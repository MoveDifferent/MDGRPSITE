# Move Different Website

Integrated consulting homepage for digital marketing, logistics, and design.

## 🚀 Deployed Live
[https://movedifferent.co.ke](https://movedifferent.co.ke) *(update when live)*

## 🛠️ Tech Stack
- React
- Tailwind CSS
- Lucide React Icons
- Netlify Forms (for contact)

## 📦 To Run Locally
```bash
npm install
npm start```